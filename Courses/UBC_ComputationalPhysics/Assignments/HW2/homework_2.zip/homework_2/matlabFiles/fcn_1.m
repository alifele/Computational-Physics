function out = fcn(x, Y)

    F1 = Y(2);
    F2 =  - Y(1);

    out = [F1; F2];

end