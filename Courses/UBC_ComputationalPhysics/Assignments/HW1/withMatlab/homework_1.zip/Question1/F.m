function result = F(x)
    result = 128.*x.^8 - 256.*x.^6 + 160.*x.^4 - 32.*x.^2 + 1;

end
