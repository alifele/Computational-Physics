function result = test(x)
    result= x.*(x-2);

end