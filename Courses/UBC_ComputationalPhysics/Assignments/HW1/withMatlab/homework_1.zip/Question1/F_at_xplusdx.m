function result = F_at_xplusdx(F, x,dx,n)
    
    result = F(x+n*dx);

end